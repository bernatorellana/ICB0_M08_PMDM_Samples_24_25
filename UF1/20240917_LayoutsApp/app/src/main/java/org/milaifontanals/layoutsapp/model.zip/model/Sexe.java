package org.milaifontanals.layoutsapp.model;

public enum Sexe {
    HOME, DONA, ALTRES
}
